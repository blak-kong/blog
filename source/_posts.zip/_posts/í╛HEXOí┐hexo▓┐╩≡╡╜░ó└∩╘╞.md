---
title: 【HEXO】hexo部署到阿里云
date: 2020-05-05 21:02:54
tags:
  - nginx
  - git
  - hexo
---

从零搭建 Hexo 博客并部署阿里云服务器（奶妈级教学）\_运维\_Object 的博客-CSDN 博客 https://blog.csdn.net/NoCortY/article/details/99631249

有一个修改文件权限的坑，不了解 linux，卡了几小时。

如果遇到了，参考下面这篇文章，chmod 这一步改成 777 即可

chmod 修改文件权限 777 和 754\_运维\_pythonw 的博客-CSDN 博客 https://blog.csdn.net/pythonw/article/details/80263428
