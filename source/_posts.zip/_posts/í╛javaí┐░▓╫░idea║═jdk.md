---
title: 【java】安装idea和jdk
date: 2020-05-29 19:06:24
tags:
---

[toc]

## 下载最新的 IDEA 2020.1

其实也可以从老版本直接升级，这里为了照顾大部分人可能第一次安装，我们选择从官网下载，下载地址为:

https://www.jetbrains.com/idea/download/

点击下载，静待下载完成~

## 开始激活

如果是第一次安装，如下图所示，我们先选择免费试用 30 天

然后跳过注册登录，进去再说

## 下载安装补丁

补丁地址：

为 IDEA 安装本地插件 jetbrains-agent.jar

安装操作

> file>setting>plugins>instsalled

选择 jar 安装

最后点击 resetIDE

重启 IDE，等待成功即可！
